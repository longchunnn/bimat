# Tổng hợp Lời giải Toàn bộ 243 Bài Lập trình Mạng (JNP) - PTIT

Thư mục này chứa đầy đủ lời giải của **toàn bộ 243 bài tập Lập trình Mạng (JNP)** được trích xuất từ ngân hàng đề thi hệ thống, chia theo 8 chủ đề lớn:

1. **`TCP/`**: 60 bài tập Socket TCP (Byte Stream, Data Stream, Character Stream, Object Stream).
2. **`UDP/`**: 33 bài tập Socket UDP (String/Byte, DataType/Numbers, Object Datagram).
3. **`RMI/`**: 54 bài tập Java RMI (`ByteService`, `CharacterService`, `DataService`, `ObjectService`).
4. **`WS/`**: 30 bài tập Web Service SOAP RPC/Literal HTTP Client.
5. **`SOAP/`**: 15 bài tập SOAP XML Envelope / HTTP POST Client.
6. **`REST/`**: 39 bài tập REST API (GET, POST, PUT, DELETE, Headers, Query Parameters, JSON).
7. **`GRPC/`**: 9 bài tập gRPC client mô phỏng chuẩn giao thức JudgeService.
8. **`MIXED/`**: 3 bài tập phối hợp đa giao thức (RMI + UDP, RMI + TCP, WS + UDP).

---

## 🏷️ Quy ước Đặt tên File & Lớp

Tất cả 243 file bài giải đều được đặt tên theo mẫu trực quan:
$$\text{<Chủ\_đề>\_<Mã\_bài>\_<Mô\_tả\_ngắn>.java}$$

Ví dụ tiêu biểu:
- `TCP_600_Tim_ten_mien_edu.java`
- `TCP_1811_Checksum_Vi_Tri_Nguyen_To.java`
- `TCP_1812_Kiem_Tra_Goi_Hex_Co_Checksum.java`
- `UDP_801_Tim_so_thieu_trong_day_khong_trung.java`
- `RMI_1311_Ma_hoa_xor_byte.java`
- `REST_2011_Tong_Cac_So_Nguyen_Trong_Mang.java`
- `WS_1411_Tinh_tong_day_so_nguyen.java`
- `SOAP_2211_Tinh_Tong_Day_So_Nguyen.java`

Tên class bên trong file khớp 100% với tên file (ví dụ `public class TCP_600_Tim_ten_mien_edu`), đảm bảo bạn có thể mở trong bất kỳ IDE nào và bấm Run ngay lập tức.

---

## 📌 Phong cách Code & Cấu trúc

- **All-in-One**: Mỗi bài tập được đóng gói hoàn chỉnh trong 1 file `.java`, chứa phương thức `public static void main(String[] args)` có thể chạy độc lập ngay lập tức.
- **Biến mở cấu hình**: Các thông số kết nối được đặt ngay đầu hàm `main`, người dùng chỉ cần sửa thông tin khi thi/làm bài:
  ```java
  String host = "36.50.135.242"; // IP Server chấm
  int port = 2206;               // Cổng dịch vụ
  String studentCode = "B23DCCN861"; // Mã sinh viên
  String qCode = "AbCdEf12";     // Mã câu hỏi
  ```
- **Tự chứa & Chuẩn Java**: Sử dụng hoàn toàn thư viện chuẩn `java.net.*`, `java.io.*`, `java.rmi.*`, `java.util.*`... Không phụ thuộc vào thư viện bên ngoài, tương thích từ Java 8 đến Java 25.
- **Javadoc Đầy đủ**: Đầu mỗi file đều có Javadoc mô tả chi tiết đề bài bằng tiếng Việt, bao gồm ví dụ Input/Output và thuật toán xử lý.

---

## 🚀 Cách Biên dịch và Chạy

### 1. Biên dịch toàn bộ một chủ đề (Ví dụ: TCP):
```bash
javac jnp_solve/TCP/*.java
```

### 2. Chạy một bài cụ thể:
```bash
java -cp jnp_solve/TCP TCP_600_Tim_ten_mien_edu
```
*(Hoặc mở thư mục `jnp_solve` trong IntelliJ IDEA / Eclipse / VS Code và nhấn Run bất kỳ file nào).*
